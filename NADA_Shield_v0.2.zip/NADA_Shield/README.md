# NADA Shield

A beginner-friendly, open-source Windows security dashboard prototype with a dark red/black interface.

## Build the Windows executable
1. Extract this folder.
2. Double-click `BUILD_EXE.bat`.
3. Wait for the dependencies and packaging to finish.
4. The executable appears at `dist\NADA Shield.exe`.

Python 3.10+ and an internet connection are needed for the build process.

## Features in v0.2
- Reads Microsoft Defender antivirus and real-time protection status.
- Reads Defender's threat detection history.
- Polls for new Defender detection records while the app is open and displays an alert.
- Offers offline, rule-based explanations of recorded detections.
- Keeps a local security event log.
- Offers confirmed actions to open Windows Security, request a quick scan, and update Defender security intelligence.
- Stores settings and history locally in `%LOCALAPPDATA%\NADA_Shield`.

## Important limitations
This is a companion dashboard, not an antivirus replacement. Microsoft Defender performs detection. Monitoring only runs while the app is open; it does not install a Windows service or run at startup. The threat explainer is local rule-based text, not a connected AI model. No AI provider is configured. Some Defender commands may require administrator rights or may be unavailable if another antivirus manages protection. Keep Windows Security enabled and updated.

NADA Shield does not automatically delete or quarantine files, and does not execute arbitrary AI-generated commands.

## Privacy
This version makes no AI API calls and does not upload threat records. History/settings are stored locally under `%LOCALAPPDATA%\NADA_Shield`.

## GitHub
Suggested repository name: `nada-shield`
Suggested description: `Open-source Windows security dashboard built around Microsoft Defender.`
