@echo off
setlocal
cd /d "%~dp0"
title Build NADA Shield
echo.
echo  NADA SHIELD - BUILD WINDOWS APP
echo  This installs required libraries and builds a standalone EXE.
echo  Internet connection required for this setup.
echo.
py -m pip install --upgrade pip
if errorlevel 1 goto failed
py -m pip install customtkinter pyinstaller
if errorlevel 1 goto failed
echo.
echo Building NADA Shield.exe...
py -m PyInstaller --noconfirm --clean --windowed --name "NADA Shield" --collect-all customtkinter nada_shield.py
if errorlevel 1 goto failed
echo.
echo SUCCESS! App created in:
echo %CD%\dist\NADA Shield.exe
pause
exit /b 0
:failed
echo.
echo Build failed. Copy the error text or send a screenshot for help.
pause
exit /b 1
