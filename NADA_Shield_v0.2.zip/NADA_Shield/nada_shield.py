import json, os, subprocess, threading, webbrowser
from datetime import datetime
import tkinter as tk
from tkinter import messagebox

try:
    import customtkinter as ctk
except ImportError:
    raise SystemExit("CustomTkinter is missing. Run BUILD_EXE.bat first.")

APP_NAME = "NADA Shield"
APP_VERSION = "0.2.0"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(os.getenv("LOCALAPPDATA", BASE_DIR), "NADA_Shield")
os.makedirs(DATA_DIR, exist_ok=True)
HISTORY_FILE = os.path.join(DATA_DIR, "history.json")
SETTINGS_FILE = os.path.join(DATA_DIR, "settings.json")

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")
BG, PANEL, RED, MUTED, GREEN, WHITE = "#09090d", "#121219", "#e5394f", "#a6a6b3", "#45d483", "#f5f5f7"

def run_powershell(command, timeout=25):
    try:
        p = subprocess.run(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "RemoteSigned", "-Command", command],
            capture_output=True, text=True, timeout=timeout,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
        )
        return p.stdout.strip(), p.stderr.strip(), p.returncode
    except Exception as exc:
        return "", str(exc), 1

def get_status():
    cmd = ("$s=Get-MpComputerStatus -ErrorAction Stop; "
           "[PSCustomObject]@{AntivirusEnabled=$s.AntivirusEnabled;"
           "RealTimeProtectionEnabled=$s.RealTimeProtectionEnabled;"
           "AntivirusSignatureLastUpdated=([string]$s.AntivirusSignatureLastUpdated);"
           "AntivirusSignatureVersion=([string]$s.AntivirusSignatureVersion)} | ConvertTo-Json -Compress")
    out, err, code = run_powershell(cmd)
    if code or not out: return None, err or out or "Defender status unavailable."
    try: return json.loads(out), None
    except Exception: return None, "Could not parse Defender status."

def get_threats():
    cmd = ("Get-MpThreatDetection -ErrorAction Stop | Select-Object ThreatID,InitialDetectionTime,"
           "LastThreatStatusChangeTime,ActionSuccess,Resources | ConvertTo-Json -Depth 4 -Compress")
    out, err, code = run_powershell(cmd)
    if code: return None, err or "Threat history unavailable."
    if not out: return [], None
    try:
        data = json.loads(out)
        return data if isinstance(data, list) else [data], None
    except Exception: return None, "Could not parse Defender threat history."

def load_json(path, fallback):
    try:
        with open(path, "r", encoding="utf-8") as f: return json.load(f)
    except Exception: return fallback

def save_json(path, data):
    try:
        with open(path, "w", encoding="utf-8") as f: json.dump(data, f, indent=2, default=str)
    except Exception: pass

def log_event(event):
    history = load_json(HISTORY_FILE, [])
    history.insert(0, {"time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "event": event})
    save_json(HISTORY_FILE, history[:250])

def explain_threat(item):
    # Offline, rule-based explanation. Does not invent a specific threat name.
    tid = item.get("ThreatID", "Unknown")
    action = item.get("ActionSuccess", None)
    resources = item.get("Resources", [])
    if isinstance(resources, str): resources = [resources]
    when = item.get("InitialDetectionTime", "time not recorded")
    lines = [
        f"Threat ID: {tid}",
        f"First detected: {when}",
        "",
        "What this means:",
        "Microsoft Defender recorded a detection. The ID alone may not tell us the exact family or severity.",
        "",
        "What to do:",
        "1. Open Windows Security and review Protection history.",
        "2. Confirm Defender's action and whether it says the threat was removed or quarantined.",
        "3. If the warning is active, follow Windows Security's recommended action.",
        "4. Don't open or run the flagged file.",
    ]
    if action is not None:
        lines += ["", f"Defender reports ActionSuccess = {action}."]
    if resources:
        lines += ["", "Recorded resource(s):"] + [str(x) for x in resources[:5]]
    lines += ["", "This explanation is generated locally from Defender's record; it is not an independent malware analysis."]
    return "\n".join(lines)

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("NADA Shield")
        self.geometry("1050x720")
        self.minsize(850, 610)
        self.configure(fg_color=BG)
        self.busy = False
        self.monitoring = False
        self.last_threat_keys = set()
        self.settings = load_json(SETTINGS_FILE, {"monitoring": True, "poll_seconds": 60})
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self.sidebar()
        self.main_area()
        self.refresh_status()
        if self.settings.get("monitoring", True):
            self.after(1500, self.start_monitoring)

    def sidebar(self):
        side = ctk.CTkFrame(self, width=210, corner_radius=0, fg_color="#0d0d13")
        side.grid(row=0, column=0, sticky="nsew"); side.grid_propagate(False)
        ctk.CTkLabel(side, text="NADA", font=ctk.CTkFont(size=29, weight="bold"), text_color=RED).pack(pady=(27,0))
        ctk.CTkLabel(side, text="SHIELD", font=ctk.CTkFont(size=15, weight="bold")).pack(pady=(0,25))
        for label, fn in [("▣  Dashboard", self.dashboard), ("⌕  Threat history", self.threat_history),
                          ("✧  Explain a threat", self.explain_page), ("◷  Security log", self.security_log),
                          ("🔔  Monitoring", self.monitor_page), ("⚙  Repair tools", self.repair_page),
                          ("ⓘ  About", self.about_page)]:
            ctk.CTkButton(side, text=label, anchor="w", height=40, fg_color="transparent",
                          hover_color="#24242d", text_color=WHITE, command=fn).pack(fill="x", padx=12, pady=3)
        ctk.CTkLabel(side, text="PROTOTYPE  •  v"+APP_VERSION+"\nUses Microsoft Defender", font=ctk.CTkFont(size=10),
                     text_color=MUTED, justify="left").pack(side="bottom", anchor="w", padx=15, pady=17)

    def main_area(self):
        self.main = ctk.CTkFrame(self, fg_color=BG, corner_radius=0)
        self.main.grid(row=0, column=1, sticky="nsew", padx=26, pady=22)
        self.main.grid_columnconfigure(0, weight=1); self.main.grid_rowconfigure(3, weight=1)
        ctk.CTkLabel(self.main, text="SECURITY CENTER", font=ctk.CTkFont(size=12, weight="bold"), text_color=RED).grid(row=0,column=0,sticky="w")
        ctk.CTkLabel(self.main, text="NADA Shield", font=ctk.CTkFont(size=30, weight="bold"), text_color=WHITE).grid(row=1,column=0,sticky="w",pady=(2,2))
        ctk.CTkLabel(self.main, text="Your PC's security, in one place.", font=ctk.CTkFont(size=14), text_color=MUTED).grid(row=2,column=0,sticky="w",pady=(0,18))
        self.content = ctk.CTkFrame(self.main, fg_color=BG)
        self.content.grid(row=3,column=0,sticky="nsew")

    def clear(self):
        for w in self.content.winfo_children(): w.destroy()

    def card(self, parent, title, value, note="", color=WHITE):
        f = ctk.CTkFrame(parent, fg_color=PANEL, corner_radius=12)
        ctk.CTkLabel(f,text=title.upper(),text_color=MUTED,font=ctk.CTkFont(size=11,weight="bold")).pack(anchor="w",padx=17,pady=(16,5))
        ctk.CTkLabel(f,text=value,text_color=color,font=ctk.CTkFont(size=21,weight="bold")).pack(anchor="w",padx=17)
        ctk.CTkLabel(f,text=note,text_color=MUTED,font=ctk.CTkFont(size=11),wraplength=320,justify="left").pack(anchor="w",padx=17,pady=(5,15))
        return f

    def dashboard(self):
        self.clear()
        grid = ctk.CTkFrame(self.content, fg_color=BG); grid.pack(fill="x")
        grid.grid_columnconfigure((0,1), weight=1)
        self.def_card = self.card(grid,"Microsoft Defender","Checking…","Reading Windows security status")
        self.def_card.grid(row=0,column=0,sticky="ew",padx=(0,7),pady=(0,12))
        self.threat_card = self.card(grid,"Threat records","Checking…","Records reported by Defender")
        self.threat_card.grid(row=0,column=1,sticky="ew",padx=(7,0),pady=(0,12))
        self.monitor_card = self.card(grid,"Background monitoring","Starting…","Checks Defender for new detection records")
        self.monitor_card.grid(row=1,column=0,sticky="ew",padx=(0,7),pady=(0,12))
        self.ai_card = self.card(grid,"Threat explanations","Offline mode","Rule-based explanations; no AI provider connected")
        self.ai_card.grid(row=1,column=1,sticky="ew",padx=(7,0),pady=(0,12))
        row=ctk.CTkFrame(self.content,fg_color=PANEL,corner_radius=12); row.pack(fill="x",pady=(2,12))
        ctk.CTkLabel(row,text="QUICK ACTIONS",text_color=RED,font=ctk.CTkFont(size=12,weight="bold")).pack(anchor="w",padx=17,pady=(14,8))
        buttons=ctk.CTkFrame(row,fg_color="transparent"); buttons.pack(fill="x",padx=14,pady=(0,14))
        ctk.CTkButton(buttons,text="Refresh status",fg_color=RED,hover_color="#bd2639",command=self.refresh_status).pack(side="left",padx=4)
        ctk.CTkButton(buttons,text="Quick scan",fg_color="#292933",hover_color="#3b3b49",command=self.quick_scan).pack(side="left",padx=4)
        ctk.CTkButton(buttons,text="Open Windows Security",fg_color="#292933",hover_color="#3b3b49",command=self.open_security).pack(side="left",padx=4)
        note=ctk.CTkFrame(self.content,fg_color="#17141a",corner_radius=12); note.pack(fill="x")
        ctk.CTkLabel(note,text="SAFE BY DESIGN",text_color=RED,font=ctk.CTkFont(size=12,weight="bold")).pack(anchor="w",padx=17,pady=(13,4))
        ctk.CTkLabel(note,text="Defender performs detection. NADA Shield shows status, checks for new detection records, and offers confirmed actions. It never runs AI-generated commands or silently deletes files.",text_color=MUTED,wraplength=700,justify="left").pack(anchor="w",padx=17,pady=(0,13))
        self.refresh_status()

    def update_card(self, card, title, value, note, color):
        for w in card.winfo_children(): w.destroy()
        ctk.CTkLabel(card,text=title.upper(),text_color=MUTED,font=ctk.CTkFont(size=11,weight="bold")).pack(anchor="w",padx=17,pady=(16,5))
        ctk.CTkLabel(card,text=value,text_color=color,font=ctk.CTkFont(size=21,weight="bold")).pack(anchor="w",padx=17)
        ctk.CTkLabel(card,text=note,text_color=MUTED,font=ctk.CTkFont(size=11),wraplength=320,justify="left").pack(anchor="w",padx=17,pady=(5,15))

    def refresh_status(self):
        if self.busy: return
        self.busy=True
        def worker():
            status,err=get_status(); threats,terr=get_threats()
            self.after(0,lambda:self.apply_status(status,err,threats,terr))
        threading.Thread(target=worker,daemon=True).start()

    def apply_status(self,status,err,threats,terr):
        self.busy=False
        if not self.winfo_exists(): return
        if hasattr(self,"def_card") and self.def_card.winfo_exists():
            if status:
                ok=bool(status.get("AntivirusEnabled")) and bool(status.get("RealTimeProtectionEnabled"))
                val="Protected" if ok else "Check settings"
                note=f"Antivirus: {'On' if status.get('AntivirusEnabled') else 'Off'} • Real-time: {'On' if status.get('RealTimeProtectionEnabled') else 'Off'}\nSignatures: {status.get('AntivirusSignatureLastUpdated','Unknown')}"
                self.update_card(self.def_card,"Microsoft Defender",val,note,GREEN if ok else RED)
            else:self.update_card(self.def_card,"Microsoft Defender","Unavailable",err or "Could not read status",RED)
        if hasattr(self,"threat_card") and self.threat_card.winfo_exists():
            self.update_card(self.threat_card,"Threat records",str(len(threats)) if threats is not None else "Unavailable",
                             "Records reported by Defender" if threats is not None else (terr or "Could not read history"),
                             GREEN if threats == [] else (RED if threats is not None else RED))
        if hasattr(self,"monitor_card") and self.monitor_card.winfo_exists():
            self.update_card(self.monitor_card,"Background monitoring","On" if self.monitoring else "Off",
                             f"Checks every {int(self.settings.get('poll_seconds',60))} seconds while this app is open",GREEN if self.monitoring else MUTED)
        if threats is not None:
            keys=set(self.threat_key(x) for x in threats)
            if self.last_threat_keys:
                new=keys-self.last_threat_keys
                if new:
                    self.after(0,lambda:self.new_threat_alert(len(new)))
            self.last_threat_keys=keys

    def threat_key(self,item):
        return str(item.get("ThreatID","?"))+"|"+str(item.get("InitialDetectionTime","?"))+"|"+str(item.get("Resources","?"))

    def new_threat_alert(self,count):
        log_event(f"Monitoring noticed {count} new Defender detection record(s).")
        try:self.bell()
        except Exception:pass
        messagebox.showwarning("NADA Shield — new Defender record",f"Microsoft Defender reported {count} new threat detection record(s).\n\nOpen Threat history or Windows Security to review them.")
        self.refresh_status()

    def start_monitoring(self):
        self.monitoring=True
        self.refresh_status()
        self.after(0,self.schedule_monitor)
        if hasattr(self,"monitor_card") and self.monitor_card.winfo_exists():
            self.update_card(self.monitor_card,"Background monitoring","On",f"Checks every {int(self.settings.get('poll_seconds',60))} seconds while this app is open",GREEN)

    def schedule_monitor(self):
        if self.monitoring:
            self.after(max(15,int(self.settings.get("poll_seconds",60)))*1000,self.monitor_tick)

    def monitor_tick(self):
        if not self.monitoring:return
        self.refresh_status()
        self.schedule_monitor()

    def monitor_page(self):
        self.clear()
        ctk.CTkLabel(self.content,text="BACKGROUND MONITORING",text_color=RED,font=ctk.CTkFont(size=13,weight="bold")).pack(anchor="w",pady=(3,12))
        ctk.CTkLabel(self.content,text="NADA Shield checks Defender's detection history while the app is open. It does not replace Defender's own real-time protection.",text_color=WHITE,wraplength=700,justify="left").pack(anchor="w",pady=(0,14))
        self.monitor_switch=ctk.CTkSwitch(self.content,text="Check for new detection records",command=self.toggle_monitor)
        self.monitor_switch.pack(anchor="w",pady=8)
        if self.settings.get("monitoring",True): self.monitor_switch.select()
        ctk.CTkLabel(self.content,text="Check interval (seconds; minimum 15)",text_color=MUTED).pack(anchor="w",pady=(18,4))
        self.interval=ctk.CTkEntry(self.content,width=160); self.interval.pack(anchor="w")
        self.interval.insert(0,str(self.settings.get("poll_seconds",60)))
        ctk.CTkButton(self.content,text="Save interval",fg_color=RED,command=self.save_interval).pack(anchor="w",pady=12)
        ctk.CTkLabel(self.content,text="For alerts while NADA Shield is closed, a Windows background service or scheduled task would be needed; this prototype does not install one.",text_color=MUTED,wraplength=700,justify="left").pack(anchor="w",pady=12)

    def toggle_monitor(self):
        self.settings["monitoring"]=bool(self.monitor_switch.get())
        save_json(SETTINGS_FILE,self.settings)
        if self.settings["monitoring"]: self.start_monitoring()
        else:
            self.monitoring=False
            log_event("Background monitoring turned off.")
        self.dashboard()

    def save_interval(self):
        try: sec=max(15,min(3600,int(self.interval.get().strip())))
        except ValueError:
            messagebox.showerror("Invalid interval","Enter a whole number from 15 to 3600."); return
        self.settings["poll_seconds"]=sec; save_json(SETTINGS_FILE,self.settings)
        log_event(f"Monitoring interval changed to {sec} seconds.")
        messagebox.showinfo("Saved",f"Monitoring interval set to {sec} seconds.")
        self.monitor_page()

    def threat_history(self):
        self.clear()
        ctk.CTkLabel(self.content,text="DEFENDER THREAT HISTORY",text_color=RED,font=ctk.CTkFont(size=13,weight="bold")).pack(anchor="w",pady=(3,10))
        box=ctk.CTkTextbox(self.content,fg_color=PANEL,text_color=WHITE,corner_radius=10); box.pack(fill="both",expand=True)
        box.insert("end","Loading…")
        def worker():
            data,err=get_threats()
            def render():
                box.delete("1.0","end")
                if err: box.insert("end","Could not read Defender history:\n"+err)
                elif not data: box.insert("end","No Defender threat records were returned.\nThis does not guarantee the PC is completely threat-free.")
                else:
                    for item in data: box.insert("end",json.dumps(item,indent=2,default=str)+"\n\n"+"-"*50+"\n\n")
            self.after(0,render)
        threading.Thread(target=worker,daemon=True).start()

    def explain_page(self):
        self.clear()
        ctk.CTkLabel(self.content,text="THREAT EXPLAINER",text_color=RED,font=ctk.CTkFont(size=13,weight="bold")).pack(anchor="w",pady=(3,8))
        ctk.CTkLabel(self.content,text="Offline explanation from Defender's recorded details. This is not a connected AI model yet.",text_color=MUTED,wraplength=700,justify="left").pack(anchor="w",pady=(0,10))
        box=ctk.CTkTextbox(self.content,fg_color=PANEL,text_color=WHITE,corner_radius=10); box.pack(fill="both",expand=True,pady=(0,10))
        box.insert("end","Loading Defender records…")
        def worker():
            data,err=get_threats()
            def render():
                box.delete("1.0","end")
                if err: box.insert("end",err)
                elif not data: box.insert("end","No detection records available to explain.\n\nIf Windows Security shows a threat, open Threat history in NADA Shield and refresh.")
                else:
                    for item in data[:10]: box.insert("end",explain_threat(item)+"\n\n"+"="*55+"\n\n")
            self.after(0,render)
        threading.Thread(target=worker,daemon=True).start()

    def security_log(self):
        self.clear()
        ctk.CTkLabel(self.content,text="SECURITY LOG",text_color=RED,font=ctk.CTkFont(size=13,weight="bold")).pack(anchor="w",pady=(3,10))
        box=ctk.CTkTextbox(self.content,fg_color=PANEL,text_color=WHITE,corner_radius=10); box.pack(fill="both",expand=True)
        events=load_json(HISTORY_FILE,[])
        if not events: box.insert("end","No NADA Shield events recorded yet.")
        else:
            for e in events: box.insert("end",f"[{e.get('time','')}] {e.get('event','')}\n\n")

    def repair_page(self):
        self.clear()
        ctk.CTkLabel(self.content,text="GUIDED REPAIR TOOLS",text_color=RED,font=ctk.CTkFont(size=13,weight="bold")).pack(anchor="w",pady=(3,10))
        ctk.CTkLabel(self.content,text="These buttons open Windows Security or request supported Defender actions. Review prompts before continuing.",text_color=MUTED,wraplength=700,justify="left").pack(anchor="w",pady=(0,14))
        ctk.CTkButton(self.content,text="Open Windows Security",fg_color=RED,command=self.open_security).pack(anchor="w",pady=5)
        ctk.CTkButton(self.content,text="Update Defender security intelligence",fg_color="#292933",command=self.update_signatures).pack(anchor="w",pady=5)
        ctk.CTkButton(self.content,text="Request a quick scan",fg_color="#292933",command=self.quick_scan).pack(anchor="w",pady=5)
        ctk.CTkLabel(self.content,text="NADA Shield does not automatically delete, quarantine, or restore files. Use Windows Security's Protection history for remediation decisions.",text_color=MUTED,wraplength=700,justify="left").pack(anchor="w",pady=18)

    def open_security(self):
        try: os.startfile("windowsdefender:")
        except Exception:
            subprocess.Popen(["cmd","/c","start","","windowsdefender:"],creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        log_event("Opened Windows Security.")

    def quick_scan(self):
        if not messagebox.askyesno("Request quick scan","Ask Microsoft Defender to start a quick scan? This can take a few minutes."):
            return
        log_event("User requested a Microsoft Defender quick scan.")
        def worker():
            out,err,code=run_powershell("Start-MpScan -ScanType QuickScan -ErrorAction Stop",timeout=20)
            if code==0:
                log_event("Defender quick scan request completed.")
                self.after(0,lambda:messagebox.showinfo("Scan requested","The request was sent to Defender. Check Windows Security for progress and results."))
            else:
                log_event("Quick scan request failed: "+(err or out or "Unknown error"))
                self.after(0,lambda:messagebox.showwarning("Could not start scan","Windows did not accept the request. Open Windows Security and start a scan there. You may need to run NADA Shield as administrator."))
        threading.Thread(target=worker,daemon=True).start()

    def update_signatures(self):
        if not messagebox.askyesno("Update Defender","Ask Microsoft Defender to check for updated security intelligence?"):
            return
        def worker():
            out,err,code=run_powershell("Update-MpSignature -ErrorAction Stop",timeout=60)
            if code==0:
                log_event("Requested Defender security intelligence update.")
                self.after(0,lambda:messagebox.showinfo("Update request complete","Defender accepted the update request."))
            else:
                log_event("Defender signature update failed: "+(err or out or "Unknown error"))
                self.after(0,lambda:messagebox.showwarning("Update unavailable","Defender could not complete the request. Open Windows Security and check for updates."))
        threading.Thread(target=worker,daemon=True).start()

    def about_page(self):
        self.clear()
        ctk.CTkLabel(self.content,text="ABOUT NADA SHIELD",text_color=RED,font=ctk.CTkFont(size=13,weight="bold")).pack(anchor="w",pady=(3,10))
        body=("NADA Shield v"+APP_VERSION+" — open-source Windows security dashboard prototype.\n\n"
              "Implemented: Defender status, detection history, app-open monitoring with alerts, offline threat explanations, security log, guided tools to open Windows Security, request a quick scan, and update Defender signatures.\n\n"
              "Not implemented yet: connected online/local AI model, monitoring while the app is closed, independent malware scanning, or automatic remediation.\n\n"
              "Safety: Microsoft Defender remains the detection engine. NADA Shield never executes AI-generated commands or silently deletes/quarantines files. Keep Windows Security enabled and updated.")
        ctk.CTkLabel(self.content,text=body,text_color=WHITE,justify="left",wraplength=700,font=ctk.CTkFont(size=14)).pack(anchor="w",padx=8,pady=8)

if __name__ == "__main__":
    app=App()
    app.mainloop()
